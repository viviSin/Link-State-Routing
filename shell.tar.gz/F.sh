#!/bin/sh
python /Users/Studyz/Documents/OneDrive/16s2/9331/ass2/Lsr.py F 2005 /Users/Studyz/Documents/OneDrive/16s2/9331/ass2/configF.txt
