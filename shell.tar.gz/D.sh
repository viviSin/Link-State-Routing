#!/bin/sh
python /Users/Studyz/Documents/OneDrive/16s2/9331/ass2/Lsr.py D 2003 /Users/Studyz/Documents/OneDrive/16s2/9331/ass2/configD.txt
