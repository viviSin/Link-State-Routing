#!/bin/sh
python /Users/Studyz/Documents/OneDrive/16s2/9331/ass2/Lsr.py A 2000 /Users/Studyz/Documents/OneDrive/16s2/9331/ass2/configA.txt
